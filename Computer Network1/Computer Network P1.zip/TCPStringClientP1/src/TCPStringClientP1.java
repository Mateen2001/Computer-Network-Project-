
import java.io.*;
import java.net.*;
import java.util.*;
public class TCPStringClientP1 {
private static final int PORT = 5000;
private static final String HOSTNAME = "localhost";
public static void main(String[] args) {
try {
	Scanner scanner = new Scanner(System.in);
	while (true) {
System.out.println("Input a sentence: ");
String requestString = scanner.nextLine(); 
if (requestString.equals("Quit")) {
	break;
	} else { 
Socket socket = new Socket(HOSTNAME, PORT); // creates the socket
DataOutputStream out = new DataOutputStream(socket.getOutputStream());
DataInputStream in = new DataInputStream(socket.getInputStream());

out.writeUTF(requestString);
out.flush();
String responseString = in.readUTF();
System.out.println(responseString);
    out.close();
    in.close();
    socket.close();
	}
}
scanner.close();
} catch(IOException e) { 
e.printStackTrace();
        }
 }
}