
import java.io.*;
import java.net.*;
import java.util.*;
public class UDPStringClientP1 {
private final static int PORT = 5000;
private static final String HOSTNAME = "localhost";
public static void main(String[] args) {
try {
DatagramSocket socket = new DatagramSocket(0);
Scanner scanner = new Scanner(System.in);
InetAddress host = InetAddress.getByName(HOSTNAME);
while (true) {

System.out.println("Input a sentence: ");
String requestString = scanner.nextLine();
if(requestString.equals("Quit")) {
	break;
} else {
byte[] requestBuffer = requestString.getBytes();
DatagramPacket request = new DatagramPacket(requestBuffer, 
requestBuffer.length, host, PORT);
socket.send(request);

DatagramPacket response = new DatagramPacket(new byte[1024], 
1024);
socket.receive(response);
String responseString = new String(response.getData());
System.out.println(responseString);
}
}
socket.close();
scanner.close();
} catch (IOException e) {
e.printStackTrace();
}
}
}
