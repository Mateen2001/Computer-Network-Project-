package P2Files;

import java.io.*;
import java.net.*;
import java.util.*;

public class TCPStringClientPersistent {
private static final int PORT = 5000;
private static final String HOSTNAME = "localhost";  
public static void main(String[] args) {
try {
	Scanner scanner = new Scanner(System.in);
	Socket socket = new Socket(HOSTNAME, PORT);
System.out.println("Connected");  
 DataOutputStream out = new DataOutputStream(socket.getOutputStream());
DataInputStream in = new DataInputStream(socket.getInputStream());

while (true) {
String line = scanner.next();
out.writeUTF(line);
out.flush();
if(line.equals("Quit")) {
	socket.close();
	break;
} else {
String response = in.readUTF();
System.out.println(response);
}
}
    out.close();
    in.close();
scanner.close();
} catch(IOException e) { 
e.printStackTrace();
}
 }
}