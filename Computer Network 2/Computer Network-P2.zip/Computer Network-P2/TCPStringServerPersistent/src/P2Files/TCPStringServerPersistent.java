package P2Files;



	import java.io.*;
	import java.net.*;
	public class TCPStringServerPersistent {
	private static int PORT = 5000;
	public static void main(String[] args) {
	        try {
	            ServerSocket server = new ServerSocket(PORT);
	            System.out.println("This is the TCP Server."); 
	            while (true) {
	            Socket connectionSocket = server.accept();
	            System.out.println("Client accepted.");
	            DataInputStream in = new DataInputStream(connectionSocket.getInputStream());
	            DataOutputStream out = new DataOutputStream(connectionSocket.getOutputStream());
	            
	            while (true) {
	            
	            String line = in.readUTF();
	            if (line.equals("Quit")) {
	            connectionSocket.close();
	            break;
	            } else {
	            String newLine = line.toUpperCase();
	            out.writeUTF(newLine);             
	            out.flush(); 
	            }
	           }
	            System.out.println("Closing connection.");
	            in.close();
	            out.close();
	            }
	        } catch(IOException e) { 
	         e.printStackTrace();
	        }
	}
	}
	         

	            

	
